PHP WEBSITE v3.0

NEW LOGS

Slight hiccup, not sure if all backend is here

