<?php
$this->load->view('templates/header.php');
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <link rel="stylesheet" href=" <?php echo base_url(); ?> css/profile/style.css ">

    <title>Document</title>
</head>

<body>
    <div class="container text-dark">
        <div class="row gutters">
            <div class="col-xl-3 col-lg-3 col-md-12 col-sm-12 col-12">
                <div class="card h-30">
                    <div class="card-body">
                        <div class="account-settings">
                            <div class="user-profile">
                                <div class="user-avatar">
                                    <img src="https://bootdey.com/img/Content/avatar/avatar7.png" alt="Maxwell Admin">
                                </div>
                                <h5 class="user-name">
                                    <?php
                                    echo "<p>" . $_SESSION["user_firstname"] . " " . $_SESSION["user_lastname"] . "</p>";
                                    ?>
                                    <h5>
                                        <h6 class="user-email">
                                            <?php
                                            echo "<p>" . $_SESSION["user_email"] . "</p>";
                                            ?>
                                        </h6>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-9 col-lg-9 col-md-12 col-sm-12 col-12">
                <div class="card h-80">
                    <div class="card-body">
                        <div class="row gutters">
                            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                                <h6 class="mb-2 text-primary">Personal Details</h6>
                            </div>
                            <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12">
                                <div class="form-group">
                                    <label for="fullName"><strong>Full Name</strong></label>
                                    <?php
                                    echo "<p>" . $_SESSION["user_firstname"] . " " . $_SESSION["user_lastname"] . "</p>";
                                    ?>
                                </div>
                            </div>
                            <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12">
                                <div class="form-group">
                                    <label for="eMail"><strong>Gender</strong></label>
                                    <p><em>Female/Male</em></p>
                                </div>
                            </div>
                            <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12">
                                <div class="form-group">
                                    <label for="phone"><strong>Age</strong></label>
                                    <p><em>00000000 years old</em></p>
                                </div>
                            </div>
                            <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12">
                                <div class="form-group">
                                    <label for="website"><strong>Nationality</strong></label>
                                    <p><em>Filipino</em></p>
                                </div>
                            </div>
                            <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12">
                                <div class="form-group">
                                    <label for="phone"><strong>Phone</strong></label>
                                    <?php
                                    echo "<p>" . $_SESSION["user_cpnumber"] . "</p>";
                                    ?>
                                </div>
                            </div>
                            <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12">
                                <div class="form-group">
                                    <label for="website"><strong>Email</strong></label>
                                    <?php
                                    echo "<p>" . $_SESSION["user_email"] . "</p>";
                                    ?>
                                </div>
                            </div>
                        </div>
                        <div class="row gutters">
                            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                                <h6 class="mt-3 mb-2 text-primary">Address</h6>
                            </div>
                            <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12">
                                <div class="form-group">
                                    <label for="Street"><strong>Street</strong></label>
                                    <?php
                                    echo "<p>" . $_SESSION["user_address"] . "</p>";
                                    ?>
                                </div>
                            </div>
                            <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12">
                                <div class="form-group">
                                    <label for="ciTy"><strong>City</strong></label>
                                    <p><em>lorem city</em></p>
                                </div>
                            </div>
                            <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12">
                                <div class="form-group">
                                    <label for="sTate"><strong>State</strong></label>
                                    <p><em>lorem lorem</em></p>
                                </div>
                            </div>
                            <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12">
                                <div class="form-group">
                                    <label for="zIp"><strong>Zip Code</strong></label>
                                    <p><em>1222222222</em></p>
                                </div>
                            </div>
                        </div>
                        <div class="row gutters">
                            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                                <h6 class="mt-3 mb-2 text-primary">Vehicle Details</h6>
                            </div>
                            <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12">
                                <div class="form-group">
                                    <label for="Street"><strong>Type</strong></label>
                                    <p><em>Car</em></p>
                                </div>
                            </div>
                            <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12">
                                <div class="form-group">
                                    <label for="ciTy"><strong>Plate No.</strong></label>
                                    <p><em>123 ABC</em></p>
                                </div>
                            </div>
                            <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12">
                                <div class="form-group">
                                    <label for="sTate"><strong>OR No.</strong></label>
                                    <p><em>lorem lorem</em></p>
                                </div>
                            </div>
                            <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12">
                                <div class="form-group">
                                    <label for="zIp"><strong>CR No.</strong></label>
                                    <p><em>1222222222</em></p>
                                </div>
                            </div>
                            <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12">
                                <div class="form-group">
                                    <label for="sTate"><strong>Vehicle Model</strong></label>
                                    <p><em>lorem lorem</em></p>
                                </div>
                            </div>
                            <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12">
                                <div class="form-group">
                                    <label for="zIp"><strong>Registration Date</strong></label>
                                    <p><em>1222222222</em></p>
                                </div>
                            </div>
                        </div>
                        <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                            <button class="btn btn-primary" type="button"> <a href="<?php echo base_url() . "users/account_update_form" ?>" class="text-light">Update</button>
                            <button class="btn btn-primary" type="button"> <a href="<?php echo base_url() . "uservehicle/addvehicle" ?>" class="text-light">Add Vehicle</a></button>
                            <button class="btn btn-danger" type='button'><a href='<?php echo base_url() . "users/account_delete_confirm" ?>'>Deactivate Account</a></button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    </div>
</header>

    <!----- FOOTER SECTION ----->
  <footer>
    <div class="social-links">
        <a href="" target="_blank"> <i class="fa fa-facebook-f"></i></a>
        <a href="" target="_blank"> <i class="fa fa-twitter"></i></a>
        <a href="" target="_blank"> <i class="fa fa-instagram"></i></a>
    </div>
    <h5>Copyright &copy;2021 PayPark | All Rights Reserved</h5>
  </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
</body>

</html>
